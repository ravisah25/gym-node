module.exports = function (app, db, sess) {
    app.post("/review", function (req, res) {

        // sess = req.session;
        // if (sess.email) {
            db.review.insert(req.body, function (err, docs) {
                res.json(docs);
            })
        // }
        // else {
        //     res.json("Session out");
        // }
    })
  

    app.get("/review", function (req, res) {
        db.review.find(function (err, docs) {
            res.json(docs);
        })
    })
    app.get('/getgymreview', function (req, res) {

        var id = req.query.id;
        db.review.find({ gymid: id }, { _id: 1, email: 1, gymid: 1, todaydate: 1, comment: 1, rating: 1 }).toArray(function (err, docs) {
            res.json(docs);
        });
    });
}